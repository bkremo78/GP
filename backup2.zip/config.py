# --- Configurare Globală ---
# Acest fișier conține constantele de configurare utilizate în întregul proiect.

# Default file to save/load participants
PARTICIPANTS_FILE = 'last_participants.json'

# Default file to save/load GUI settings
GUI_SETTINGS_FILE = 'gui_settings.json'

# Default CSV file with historical data
DEFAULT_CSV_FILE = 'Towcester.csv' # <<< Asigurați-vă că acest fișier există și este în același director


# Maparea numelor pistelor din GUI la abrevierile din fișierul CSV istoric
# Folosita in GUI pentru afisare si in logica pentru filtrarea istoricului
TRACK_NAME_MAP_GUI_TO_CSV = {
    'Romford': 'ROM',
    'Towcester': 'Tow', # Asigurati-va ca 'Tow' este abrevierea exacta din CSV
    'Harlow': 'Har',
    'Monmore': 'MON',
    'Sheffield': 'Sheff',
    # Adaugati aici alte piste din GUI si abrevierile lor din CSV
}

# Detalii default pentru cursa nouă în GUI
DEFAULT_CURSA_NOUA_GUI = {
    'pista': 'Towcester', # Numele pistei din cheile de mai sus (GUI name)
    'distanta_m': 500,    # Distanța în metri
    'grad': 'A2',         # Gradul cursei (string)
    # Data cursei default nu mai e specificata aici, se incarca din gui_settings.json sau e goala
}

# Distantele aproximative ale punctelor intermediare (in metri) per pista si distanta
# Folosit pentru simularea cursei
DISTANTE_PUNCTE_SIMULARE = {
    'Tow': { # Folositi abrevierea din CSV
        500: [100, 250, 350, 450], # Exemplu pentru Towcester 500m
        # Adaugati alte distante si puncte intermediare pentru alte piste/distante
    },
    'Har': { # Exemplu pentru Romford
        415: [80, 120, 280, 320],
        592: [50, 150, 300, 450, 550],
     },
     'ROM': { # Exemplu pentru Romford
        400: [50, 150, 250, 350],
        575: [50, 150, 300, 450, 525],
     },
     'Sheff': { # Exemplu pentru Sheffield
        400: [50, 150, 250, 350],
        500: [100, 250, 350, 450],
     },
     # Adaugati configuratii pentru alte piste si distante
}


# --- Ajustări bazate pe Atributele Ogarului ---
# Aceste valori sunt ajustări (în secunde) adăugate la timpul prezis.
# Valori pozitive înseamnă un timp mai lent estimat, valori negative un timp mai rapid.

# Ajustări bazate pe Vârstă
YOUNG_AGE_THRESHOLD = 2.5  # ani (sub aceasta varsta e considerat tanar)
OLD_AGE_THRESHOLD = 4.5   # ani (peste aceasta varsta e considerat batran)
YOUNG_AGE_ADJUSTMENT = 0.2 # secunde adăugate pentru ogarii tineri
OLD_AGE_ADJUSTMENT = 0.1  # secunde adăugate pentru ogarii bătrâni


# Ajustări bazate pe Sex
SEX_ADJUSTMENTS = {
    'M': 0.0,
    'F': 0.1,  # Femelele estimate cu 0.1s mai lent decat Masculii (exemplu)
    'D': 0.0,  # Dogs (Masculi) - putem folosi si M sau D, in functie de CSV
    'B': 0.1,  # Bitches (Femele) - putem folosi si F sau B, in functie de CSV
    'N/A': 0.0 # Default pentru sex necunoscut/indisponibil
}

# Factorul de Ajustare bazat pe Poziția Boxului de Start (Box Curent vs Medie Box Start)
# Formula: (Box Curent - Medie Box Start) * BOX_POSITION_ADJUSTMENT_FACTOR
# O medie Box Start mai mică decât boxul curent (ex: ogarul pleacă de obicei din boxuri mici dar acum e in box mare) duce la o ajustare pozitivă (timp mai lent).
# O medie Box Start mai mare decât boxul curent (ex: ogarul pleacă de obicei din boxuri mari dar acum e in box mic) duce la o ajustare negativă (timp mai rapid).
# Valoarea 0.03s/box este un exemplu; ajustează această valoare pe baza analizei datelor tale.
BOX_POSITION_ADJUSTMENT_FACTOR = 0.03


# Ajustări bazate pe Gradul Cursei Curente
# Ajustarea (în secunde) aplicată pe baza gradului CURSEI CURENTE.
# Comparativ cu un grad de referință (de exemplu, A1 = 0.0).
# Valori pozitive pentru grade "mai slabe" (timp mai lent), negative pentru grade "mai bune" (timp mai rapid).
# Exemplu: A2 e cu 0.1s mai lent decat A1, A3 cu 0.2s mai lent decat A1, etc.
GRADE_ADJUSTMENTS = {
    'A1': 0.0,
    'A2': 0.1,
    'A3': 0.2,
    'A4': 0.3,
    'A5': 0.4,
    'A6': 0.5,
    'A7': 0.6,
    'A8': 0.7,
    'A9': 0.8,
    'A10': 0.9,
    # Adaugati aici celelalte grade relevante din CSV
    # Gradele B1, B2 etc. ar putea avea ajustari diferite fata de A-uri pentru aceeasi distanta, daca e cazul.
    # Puteți folosi grade generice dacă cele din CSV variază ('Open', 'Standard', etc.)
    'OPEN': 0.0, # Exemplu
    'STANDARD': 0.5, # Exemplu
    '': 0.5, # Default pentru grad gol/necunoscut
    'N/A': 0.5 # Default pentru grad N/A
}


# --- Ajustări bazate pe Recența Formei ---
# Ajustarea (în secunde) aplicată pe baza cât timp a trecut de la ultima cursă relevantă.
# Definește pragurile în zile pentru diferitele statusuri de recență.
RECENCY_THRESHOLD_RECENT_DAYS = 30    # Zile (<=30 = Very Recent)
RECENCY_THRESHOLD_MODERATE_DAYS = 90  # Zile (>30 si <=90 = Recent)
RECENCY_THRESHOLD_OLD_DAYS = 180   # Zile (>90 si <=180 = Moderate)
# Zile > 180 = Old
# Recency Statuses: 'Very Recent', 'Recent', 'Moderate', 'Old', 'No History', 'N/A Date'

# Ajustarea (în secunde) pentru fiecare status de recență.
# Penalizari mai mari pentru lipsa de recență sau date lipsă.
RECENCY_ADJUSTMENTS = {
    'Very Recent': 0.0,
    'Recent': 0.1,
    'Moderate': 0.2,
    'Old': 0.3,
    'No History': 0.5, # Nu exista istoric relevant Pista+Distanta
    'N/A Date': 0.5 # Exista istoric relevant, dar data nu a putut fi parsata pentru ultima cursa.
}

# Valoare mare pentru a reprezenta un timp "necunoscut" sau "foarte lent".
TIMP_MAX_NECUNOSCUT = 999.99